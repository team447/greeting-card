// app.jsx — main microsite app with 5-step flow

const { useState, useEffect, useRef, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "occasion": "holiday",
  "campaignName": "Season's Greetings",
  "campaignTag": "MMXXVI · A note for those who matter"
}/*EDITMODE-END*/;

const STEPS = [
  { id: "auth",     label: "Sign in" },
  { id: "name",     label: "Your name" },
  { id: "avatar",   label: "Portrait" },
  { id: "message",  label: "Your wish" },
  { id: "generate", label: "Generate" },
];

/* ───────────────────────── BRAND TOPBAR ───────────────────────── */
function TopBar({ campaignName, campaignTag }){
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark">S</div>
        <div>
          <div className="brand-name">{campaignName.split(' ')[0]} <em>{campaignName.split(' ').slice(1).join(' ')}</em></div>
          <div className="brand-tag">{campaignTag}</div>
        </div>
      </div>
      <div className="topbar-meta"><span className="dot"></span>Campaign live · 2026</div>
    </header>
  );
}

/* ───────────────────────── PROGRESS RAIL ───────────────────────── */
function Rail({ stepIdx }){
  return (
    <div className="rail">
      {STEPS.map((s, i) => {
        const cls = i < stepIdx ? "done" : (i === stepIdx ? "active" : "");
        return (
          <div key={s.id} className={`rail-step ${cls}`}>
            <div className="rail-bar"><i /></div>
            <div className="rail-lbl">
              <span className="rail-num">{String(i+1).padStart(2,'0')}</span>
              <span>{s.label}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ─────────── ICONS (original, not branded) ─────────── */
const Ic = {
  google: (
    <svg className="ic" viewBox="0 0 24 24" aria-hidden>
      <path fill="#fff" opacity=".95" d="M12 11v2.7h4.7c-.2 1.2-1.6 3.4-4.7 3.4-2.8 0-5.1-2.3-5.1-5.2s2.3-5.2 5.1-5.2c1.6 0 2.7.7 3.3 1.3l2.2-2.1C16 4.6 14.2 3.7 12 3.7 7.6 3.7 4 7.3 4 11.9s3.6 8.2 8 8.2c4.6 0 7.7-3.2 7.7-7.8 0-.5 0-1-.1-1.4H12z" />
    </svg>
  ),
  facebook: (
    <svg className="ic" viewBox="0 0 24 24" aria-hidden>
      <path fill="#fff" opacity=".95" d="M13.5 22v-8h2.7l.4-3.1h-3.1V8.9c0-.9.3-1.5 1.5-1.5h1.6V4.6c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8v2.5H8v3.1h2.7V22h2.8z" />
    </svg>
  ),
  guest: (
    <svg className="ic" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.6" aria-hidden>
      <circle cx="12" cy="8" r="3.4" />
      <path d="M5 20c0-3.6 3.1-6.5 7-6.5s7 2.9 7 6.5" strokeLinecap="round" />
    </svg>
  ),
  arrow: (<svg className="arr" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M2 8 H14 M9 3 L14 8 L9 13" /></svg>),
  back:  (<svg className="arr" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M14 8 H2 M7 3 L2 8 L7 13" /></svg>),
  upload:(<svg className="drop-ic" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"><path d="M16 22 V8 M10 14 L16 8 L22 14" /><path d="M5 22 V25 Q5 27 7 27 H25 Q27 27 27 25 V22" /></svg>),
  fb:    (<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 22v-8h2.7l.4-3.1h-3.1V8.9c0-.9.3-1.5 1.5-1.5h1.6V4.6c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8v2.5H8v3.1h2.7V22h2.8z" /></svg>),
  dl:    (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"><path d="M12 4 V16 M7 11 L12 16 L17 11" /><path d="M5 19 H19" /></svg>),
  send:  (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round"><path d="M3 12 L21 4 L17 21 L11 14 L4 12 Z" /></svg>),
  mail:  (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="6" width="18" height="13" rx="1.5"/><path d="M3 7 L12 13 L21 7" /></svg>),
  link:  (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M10 14 L14 10 M9 7 H7 A5 5 0 0 0 7 17 H9 M15 7 H17 A5 5 0 0 1 17 17 H15" /></svg>),
  msg:   (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M4 5 H20 V16 H13 L9 20 V16 H4 Z" /></svg>),
};

/* ───────────────────────── STEP 1 — AUTH ───────────────────────── */
function AuthStep({ campaignName, onAuth }){
  return (
    <section className="panel scene-enter">
      <div className="panel-grid">
        <div>
          <p className="eyebrow">Step 01 · Begin</p>
          <h1 className="h1">Send a card<br/>that feels <em>handwritten</em>.</h1>
          <p className="lede">In one minute, craft a personalised greeting card with your name, your portrait, and a message of your own. Share it across your channels — or keep it just between two friends.</p>
          <div className="ornament"><span className="ln"></span>✦<span className="ln"></span></div>
        </div>
        <div>
          <p className="eyebrow" style={{textAlign:'left'}}>Continue with</p>
          <div className="login-stack">
            <button className="login-btn" onClick={() => onAuth('google',  'Jordan Reyes')}>{Ic.google}Continue with Google</button>
            <button className="login-btn" onClick={() => onAuth('facebook','Jordan Reyes')}>{Ic.facebook}Continue with Facebook</button>
            <div className="login-divider">or</div>
            <button className="login-btn" onClick={() => onAuth('guest', '')}>{Ic.guest}View as Guest</button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── STEP 2 — NAME ───────────────────────── */
function NameStep({ value, onChange, onNext, onBack }){
  const ref = useRef();
  useEffect(() => { ref.current?.focus(); }, []);
  return (
    <section className="panel scene-enter">
      <div className="panel-grid">
        <div>
          <p className="eyebrow">Step 02 · Your Name</p>
          <h1 className="h1">What shall we<br/>call <em>you</em>?</h1>
          <p className="lede">This appears in elegant serif at the centre of your card — exactly the way you'd see it on a formal certificate or wedding invitation.</p>
          <button className="back" onClick={onBack}>{Ic.back} Back</button>
        </div>
        <div>
          <div className="field">
            <div className="field-lbl"><span>Full name</span><span className="var">[user_name]</span></div>
            <input ref={ref} className="input" value={value} maxLength={40}
              placeholder="e.g. Jordan Reyes"
              onChange={(e)=>onChange(e.target.value)}
              onKeyDown={(e)=>{ if(e.key==='Enter' && value.trim()) onNext(); }} />
          </div>
          <button className="btn primary lg" disabled={!value.trim()} onClick={onNext}>Continue {Ic.arrow}</button>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── STEP 3 — AVATAR ───────────────────────── */
function AvatarStep({ value, onChange, onNext, onBack, onSkip }){
  const inputRef = useRef();
  const [over, setOver] = useState(false);

  const handleFile = (file) => {
    if (!file || !file.type?.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => onChange(reader.result);
    reader.readAsDataURL(file);
  };

  return (
    <section className="panel scene-enter">
      <div className="panel-grid">
        <div>
          <p className="eyebrow">Step 03 · Your Portrait</p>
          <h1 className="h1">Add a <em>portrait</em>,<br/>or a favourite photo.</h1>
          <p className="lede">Your image becomes a gold-rimmed medallion at the heart of the card. Square photos work best; round crop is automatic.</p>
          <button className="back" onClick={onBack}>{Ic.back} Back</button>
        </div>
        <div>
          <div className="field">
            <div className="field-lbl"><span>Profile photo</span><span className="var">[user_avatar]</span></div>
            <div
              className={`drop ${value ? 'has' : ''} ${over ? 'over' : ''}`}
              onClick={() => inputRef.current?.click()}
              onDragOver={(e)=>{ e.preventDefault(); setOver(true); }}
              onDragLeave={()=>setOver(false)}
              onDrop={(e)=>{ e.preventDefault(); setOver(false); handleFile(e.dataTransfer.files[0]); }}
            >
              {value
                ? <><img src={value} alt="" /><div className="drop-replace">Click to replace</div></>
                : <div className="drop-inner">
                    {Ic.upload}
                    <div className="drop-hint">Drop or click to upload</div>
                    <div className="drop-sub">JPG · PNG · up to 5MB</div>
                  </div>}
            </div>
            <input ref={inputRef} type="file" accept="image/*" hidden onChange={(e)=>handleFile(e.target.files[0])} />
          </div>
          <div className="row">
            <button className="btn primary" disabled={!value} onClick={onNext}>Continue {Ic.arrow}</button>
            <button className="btn ghost" onClick={onSkip}>Skip for now</button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────────── STEP 4 — MESSAGE ───────────────────────── */
function MessageStep({ value, onChange, onNext, onBack }){
  const ref = useRef();
  useEffect(() => { ref.current?.focus(); }, []);
  const MAX = 220;
  return (
    <section className="panel scene-enter">
      <div className="panel-grid">
        <div>
          <p className="eyebrow">Step 04 · Your Wish</p>
          <h1 className="h1">Now write<br/>your <em>message</em>.</h1>
          <p className="lede">This is the heart of the card — set in a flowing handwritten script at its centre. Keep it warm, keep it personal. A sentence or two is plenty.</p>
          <button className="back" onClick={onBack}>{Ic.back} Back</button>
        </div>
        <div>
          <div className="field">
            <div className="field-lbl"><span>Greeting message</span><span className="var">[user_message]</span></div>
            <textarea ref={ref} className="textarea" value={value} maxLength={MAX}
              placeholder="Wishing you warmth, laughter, and a year filled with everything you've been hoping for…"
              onChange={(e)=>onChange(e.target.value)} />
            <div className="count">{value.length} / {MAX}</div>
          </div>
          <button className="btn primary lg" disabled={!value.trim()} onClick={onNext}>Generate card {Ic.arrow}</button>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────── STEP 5 — GENERATING ───────────────────── */
function GeneratingStep(){
  const lines = [
    "Pressing seal · embossing border",
    "Composing monogram · ruling lines",
    "Setting your name · in Garamond",
    "Inking your message · in Caveat",
    "Final review · curing gold leaf",
  ];
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((x) => Math.min(x+1, lines.length-1)), 520);
    return () => clearInterval(t);
  }, []);
  return (
    <section className="panel scene-enter">
      <div className="generate">
        <div className="seal">
          <svg viewBox="0 0 120 120">
            <defs>
              <radialGradient id="genGrad" cx=".5" cy=".5">
                <stop offset="0%" stopColor="oklch(0.92 0.06 80)" />
                <stop offset="100%" stopColor="oklch(0.78 0.12 80)" />
              </radialGradient>
            </defs>
            <g className="ring1">
              {Array.from({length: 24}).map((_,k)=>{
                const a = (k/24)*Math.PI*2;
                return <line key={k} x1={60+Math.cos(a)*44} y1={60+Math.sin(a)*44} x2={60+Math.cos(a)*52} y2={60+Math.sin(a)*52} stroke="oklch(0.78 0.12 80)" strokeWidth="1" />;
              })}
            </g>
            <g className="ring2">
              <circle cx="60" cy="60" r="38" fill="none" stroke="oklch(0.78 0.12 80 / .6)" strokeWidth="0.6" strokeDasharray="2 4" />
            </g>
            <g className="pulse">
              <circle cx="60" cy="60" r="32" fill="url(#genGrad)" stroke="oklch(0.48 0.10 60)" strokeWidth="1" />
              <text x="60" y="71" textAnchor="middle" fontFamily="Cormorant Garamond" fontStyle="italic" fontWeight="600" fontSize="32" fill="oklch(0.48 0.10 60)">✦</text>
            </g>
          </svg>
        </div>
        <div>
          <h1 className="h1" style={{textAlign:'center', margin: 0}}>Crafting your card…</h1>
        </div>
        <div className="row" style={{justifyContent:'center'}}>
          <div className="loading-bars"><i/><i/><i/><i/><i/></div>
          <div className="loading-line">{lines[i]}</div>
        </div>
      </div>
    </section>
  );
}

/* ───────────────────── FINAL — CARD VIEW ───────────────────── */
function FinalStep({ name, avatar, message, occasion, cardId, dateLabel, onShareFB, onDownload, onSend, onRestart }){
  return (
    <section className="scene-enter">
      <div className="final-wrap">
        <div className="final-meta">
          <span>✦ Card #{cardId}</span>
          <span>· Ready to send ·</span>
        </div>
        <GreetingCard name={name} avatar={avatar} message={message} occasion={occasion} cardId={cardId} dateLabel={dateLabel} />
        <div className="final-actions">
          <button className="btn lg" onClick={onShareFB} style={{background:'#1877F2', borderColor:'transparent'}}>{Ic.fb}Share on Facebook</button>
          <button className="btn lg" onClick={onDownload}>{Ic.dl}Download as image</button>
          <button className="btn primary lg" onClick={onSend}>{Ic.send}Send to a friend</button>
        </div>
        <button className="final-restart" onClick={onRestart}>← Create another card</button>
      </div>
    </section>
  );
}

/* ─────────────────────── SEND-TO-FRIEND MODAL ─────────────────────── */
function SendModal({ onClose, onSend, name }){
  const [to, setTo] = useState('');
  const [note, setNote] = useState(`Hi! I made this for you — hope it brightens your day. — ${name || 'your friend'}`);
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" style={{position:'relative'}} onClick={(e)=>e.stopPropagation()}>
        <button className="modal-x" onClick={onClose}>×</button>
        <h3>Send your card</h3>
        <p>We'll email a link to your friend with a preview of the card.</p>
        <div className="field">
          <div className="field-lbl"><span>Their email</span></div>
          <input className="input" type="email" placeholder="friend@example.com" value={to} onChange={(e)=>setTo(e.target.value)} />
        </div>
        <div className="field">
          <div className="field-lbl"><span>A short note</span></div>
          <textarea className="textarea" value={note} onChange={(e)=>setNote(e.target.value)} style={{minHeight:90}} />
        </div>
        <div className="row" style={{justifyContent:'space-between', marginTop:8}}>
          <div className="modal-row" style={{margin:0, gap:8}}>
            <button className="modal-chip" title="Copy link" onClick={()=>onSend('link', to)}>{Ic.link}Copy link</button>
            <button className="modal-chip" title="SMS"        onClick={()=>onSend('sms', to)}>{Ic.msg}SMS</button>
          </div>
          <button className="btn primary" disabled={!to} onClick={()=>onSend('email', to)}>{Ic.mail}Send email</button>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────── ROOT APP ─────────────────────────── */
function App(){
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [stepIdx, setStepIdx] = useState(0);
  const [authMethod, setAuthMethod] = useState(null);
  const [name, setName] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [message, setMessage] = useState('');
  const [cardMeta, setCardMeta] = useState(null);
  const [toast, setToast] = useState(null);
  const [showSend, setShowSend] = useState(false);

  const showToast = useCallback((txt) => {
    setToast(txt);
    setTimeout(() => setToast(null), 2400);
  }, []);

  // === Step handlers
  const handleAuth = (method, suggestedName) => {
    setAuthMethod(method);
    if (suggestedName && !name) setName(suggestedName);
    setStepIdx(1);
  };

  const goToGenerate = () => {
    setStepIdx(4);
    setTimeout(() => {
      const id = String(Math.floor(100000 + Math.random()*900000));
      const d = new Date();
      const dateLabel = d.toLocaleDateString('en-US', { day:'numeric', month:'long', year:'numeric' });
      setCardMeta({ cardId: id, dateLabel });
      setStepIdx(5); // final
    }, 2700);
  };

  const handleRestart = () => {
    setStepIdx(0);
    setAuthMethod(null);
    setName('');
    setAvatar(null);
    setMessage('');
    setCardMeta(null);
  };

  // === Final actions
  const cardRef = useRef();
  const doDownload = async () => {
    const el = document.getElementById('gcard');
    if (!el) return showToast('Card not ready');
    try {
      const dataUrl = await htmlToImage.toPng(el, { pixelRatio: 2, cacheBust: true, backgroundColor: null });
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `greeting-card-${cardMeta?.cardId || 'card'}.png`;
      a.click();
      showToast('Downloaded ✦');
    } catch (e) {
      console.error(e);
      showToast('Download failed');
    }
  };
  const doShareFB = () => {
    const url = encodeURIComponent(window.location.href);
    const quote = encodeURIComponent(`I made a greeting card — "${(message||'').slice(0,80)}"`);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${quote}`, '_blank', 'noopener,width=620,height=520');
  };
  const doSend = (channel, to) => {
    setShowSend(false);
    if (channel === 'link') {
      navigator.clipboard?.writeText(window.location.href);
      showToast('Link copied to clipboard');
    } else if (channel === 'sms') {
      showToast(`SMS preview sent to ${to}`);
    } else {
      showToast(`Card sent to ${to} ✦`);
    }
  };

  // === Determine which step UI to show
  const renderStep = () => {
    if (stepIdx === 0) return <AuthStep campaignName={t.campaignName} onAuth={handleAuth} />;
    if (stepIdx === 1) return <NameStep value={name} onChange={setName} onNext={() => setStepIdx(2)} onBack={() => setStepIdx(0)} />;
    if (stepIdx === 2) return <AvatarStep value={avatar} onChange={setAvatar} onNext={() => setStepIdx(3)} onBack={() => setStepIdx(1)} onSkip={() => setStepIdx(3)} />;
    if (stepIdx === 3) return <MessageStep value={message} onChange={setMessage} onNext={goToGenerate} onBack={() => setStepIdx(2)} />;
    if (stepIdx === 4) return <GeneratingStep />;
    if (stepIdx === 5) return (
      <FinalStep name={name} avatar={avatar} message={message} occasion={t.occasion}
        cardId={cardMeta?.cardId} dateLabel={cardMeta?.dateLabel}
        onShareFB={doShareFB} onDownload={doDownload} onSend={() => setShowSend(true)} onRestart={handleRestart}
      />
    );
  };

  // Use a key to force re-mount + animation on step change
  return (
    <div className="shell" data-step={stepIdx}>
      <TopBar campaignName={t.campaignName} campaignTag={t.campaignTag} />
      {stepIdx < 5 && <Rail stepIdx={Math.min(stepIdx, 4)} />}
      <div className="stage">
        <div className="scene" key={stepIdx}>
          {renderStep()}
        </div>
      </div>

      {toast && <div className="toast">✦ {toast}</div>}
      {showSend && <SendModal onClose={() => setShowSend(false)} onSend={doSend} name={name} />}

      <TweaksPanel>
        <TweakSection label="Campaign" />
        <TweakText label="Campaign name" value={t.campaignName} onChange={(v)=>setTweak('campaignName', v)} />
        <TweakText label="Tagline"       value={t.campaignTag}  onChange={(v)=>setTweak('campaignTag', v)} />
        <TweakSection label="Card theme" />
        <TweakSelect label="Occasion" value={t.occasion}
          options={[
            {value:'holiday',     label:"Season's Greetings"},
            {value:'birthday',    label:'Happy Birthday'},
            {value:'tet',         label:'Lunar New Year (Tết)'},
            {value:'thanks',      label:'Thank You'},
            {value:'anniversary', label:'Anniversary'},
          ]}
          onChange={(v)=>setTweak('occasion', v)} />
        <TweakSection label="Demo" />
        <TweakButton label="Jump to final card" onClick={() => {
          if (!name) setName('Jordan Reyes');
          if (!message) setMessage("Wishing you a year filled with warmth, wonder, and the company of those you love most.");
          const id = String(Math.floor(100000 + Math.random()*900000));
          const d = new Date();
          setCardMeta({ cardId: id, dateLabel: d.toLocaleDateString('en-US',{day:'numeric',month:'long',year:'numeric'}) });
          setStepIdx(5);
        }} />
        <TweakButton label="Restart flow" onClick={handleRestart} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
