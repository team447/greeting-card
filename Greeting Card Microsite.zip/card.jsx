// card.jsx — the certificate-style greeting card
// exposes window.GreetingCard

const OCCASIONS = {
  holiday: { eyebrow: "Season's Greetings — MMXXVI", title: "Season's Greetings", sub: "With Warmest Wishes For The Year Ahead", acks: "This card is sent with affection to", from: "From a friend" },
  birthday: { eyebrow: "A Day To Celebrate", title: "Happy Birthday", sub: "Many Happy Returns Of The Day", acks: "This card is sent in celebration of", from: "With love" },
  tet: { eyebrow: "Chúc Mừng Năm Mới — Giáp Thìn", title: "Happy Lunar New Year", sub: "An Tài • Phát Lộc • Vạn Sự Như Ý", acks: "Sent with prosperity and good fortune to", from: "Trân trọng" },
  thanks: { eyebrow: "A Note Of Appreciation", title: "Thank You", sub: "With Sincere Gratitude", acks: "This note of thanks is presented to", from: "With gratitude" },
  anniversary: { eyebrow: "Marking A Milestone", title: "Happy Anniversary", sub: "Cheers To Another Wonderful Year", acks: "With heartfelt admiration for", from: "Yours always" }
};

function CornerFlourish({ className }) {
  return (
    <svg className={`gcard-corner ${className}`} viewBox="0 0 56 56" fill="none" stroke="currentColor" strokeWidth="1.1">
      <path d="M0 28 L0 14 Q0 0 14 0 L28 0" />
      <path d="M8 28 L8 18 Q8 8 18 8 L28 8" opacity=".55" />
      <circle cx="14" cy="14" r="2.5" fill="currentColor" stroke="none" />
      <path d="M22 8 Q26 12 22 16 M16 22 Q12 26 8 22" strokeLinecap="round" />
    </svg>);

}

function MonogramSeal({ initial }) {
  return (
    <div className="gcard-seal">
      <svg className="gcard-seal-bg" viewBox="0 0 76 76">
        <defs>
          <radialGradient id="sealGrad" cx="0.5" cy="0.35">
            <stop offset="0%" stopColor="oklch(0.92 0.06 80)" />
            <stop offset="100%" stopColor="oklch(0.78 0.12 80)" />
          </radialGradient>
        </defs>
        <circle cx="38" cy="38" r="33" fill="url(#sealGrad)" stroke="oklch(0.48 0.10 60)" strokeWidth="1" />
        <circle cx="38" cy="38" r="29" fill="none" stroke="oklch(0.48 0.10 60)" strokeWidth="0.5" strokeDasharray="1.5 2.5" />
        {Array.from({ length: 16 }).map((_, i) => {
          const a = i / 16 * Math.PI * 2;
          const x1 = 38 + Math.cos(a) * 30,y1 = 38 + Math.sin(a) * 30;
          const x2 = 38 + Math.cos(a) * 34,y2 = 38 + Math.sin(a) * 34;
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="oklch(0.48 0.10 60)" strokeWidth="0.6" />;
        })}
      </svg>
      <div className="gcard-seal-text">{initial || "✦"}</div>
    </div>);

}

function Avatar({ src, name }) {
  const initial = (name || "").trim().charAt(0).toUpperCase() || "✦";
  return (
    <div className="gcard-medallion">
      <div className="gcard-medallion-ring">
        {src ?
        <img className="gcard-medallion-img" src={src} alt={name} /> :
        <div className="gcard-medallion-init">{initial}</div>}
      </div>
    </div>);

}

function GreetingCard({ name, avatar, message, occasion = "holiday", cardId, dateLabel }) {
  const data = OCCASIONS[occasion] || OCCASIONS.holiday;
  const initial = (name || "").trim().charAt(0).toUpperCase() || "✦";
  const displayName = (name || "").trim() || "Dear Friend";
  const displayMsg = (message || "").trim() || "Wishing you a year filled with warmth, wonder, and the company of those you love most.";

  return (
    <div className="card-stage">
      <div className={`gcard theme-${occasion}`} id="gcard">
        {/* Frame and corners */}
        <div className="gcard-frame"></div>
        <CornerFlourish className="tl" />
        <CornerFlourish className="tr" />
        <CornerFlourish className="bl" />
        <CornerFlourish className="br" />

        {/* Seal */}
        <MonogramSeal initial={initial} />

        {/* Eyebrow */}
        <div className="gcard-eyebrow">{data.eyebrow}</div>

        {/* Ornament + Title */}
        <div className="gcard-ornament">
          <span className="ln"></span>
          <span className="di"></span>
          <span className="ln"></span>
        </div>
        <h1 className="gcard-title">{data.title}</h1>
        <p className="gcard-sub">{data.sub}</p>

        {/* Avatar */}
        <Avatar src={avatar} name={name} />

        {/* Acknowledgement + Name */}
        <p className="gcard-acks">{data.acks}</p>
        <h2 className="gcard-name">{displayName}</h2>
        <div className="gcard-name-rule"></div>

        {/* Message */}
        <div className="gcard-msg-wrap">
          <div className="gcard-msg-lbl">— A Personal Message —</div>
          <p className="gcard-msg">{displayMsg}</p>
        </div>

        {/* Footer */}
        <div className="gcard-foot">
          <div className="gcard-foot-l">
            <div className="gcard-foot-k">Issued</div>
            <div className="gcard-foot-v">{dateLabel}</div>
          </div>
          <div className="gcard-foot-r">
            <div className="gcard-foot-rule"></div>
            <div className="gcard-foot-v">{data.from}</div>
            <div className="gcard-foot-k">Card · {cardId}</div>
          </div>
        </div>
      </div>
    </div>);

}

Object.assign(window, { GreetingCard, OCCASIONS });